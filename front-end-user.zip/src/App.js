import React from "react";
import Nav_Bar from "./Components/navbar";


const App = () => {
  return (
    <>
      <Nav_Bar />

    </>
  );
};

export default App;
